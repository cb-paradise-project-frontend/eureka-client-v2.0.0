export const OPEN = 'OPEN'; 
export const ASSIGNED = 'ASSIGNED'; 
export const COMPLETED = 'COMPLETED'; 
export const EXPIRED = 'EXPIRED'; 
