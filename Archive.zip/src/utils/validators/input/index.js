export { default } from './onlyNumber';
export { default as onlyNumber } from './onlyNumber';
export { default as addDashInNumber } from './addDashInNumber';
