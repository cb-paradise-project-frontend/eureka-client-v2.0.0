export { default as isAdult } from './isAdult';
export { default as isDate } from './isDate';